#!/usr/bin/env python3

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.services.email_service import EmailService
from src.models.user import User
from src.models.pdf_summary import PDFSummary
from datetime import datetime, timedelta

def test_email_service():
    """Test the email service functionality."""
    print("Testing Email Service...")
    
    # Create a mock user for testing
    mock_user = type('MockUser', (), {
        'id': 1,
        'username': 'testuser',
        'email': 'test@example.com',
        'notification_email': 'test@example.com'
    })()
    
    # Create mock summaries
    mock_summaries = [
        type('MockSummary', (), {
            'id': 1,
            'title': 'AI and Machine Learning Research Paper',
            'summary': 'This paper explores the latest developments in artificial intelligence and machine learning, focusing on deep learning architectures and their applications in natural language processing.',
            'key_messages': 'Deep learning shows significant improvements\nTransformer models are state-of-the-art\nFuture research should focus on efficiency',
            'google_drive_link': 'https://drive.google.com/file/d/example1',
            'date_added': datetime.now() - timedelta(days=2)
        })(),
        type('MockSummary', (), {
            'id': 2,
            'title': 'Climate Change Impact Report',
            'summary': 'A comprehensive analysis of climate change impacts on global ecosystems, including rising sea levels, temperature changes, and biodiversity loss.',
            'key_messages': 'Global temperatures rising faster than expected\nImmediate action required to prevent catastrophic changes\nRenewable energy adoption is crucial',
            'google_drive_link': 'https://drive.google.com/file/d/example2',
            'date_added': datetime.now() - timedelta(days=1)
        })()
    ]
    
    try:
        # Initialize email service
        email_service = EmailService()
        
        # Test HTML generation
        print("Testing HTML email generation...")
        html_content = email_service.generate_weekly_summary_html(mock_user, mock_summaries)
        print(f"✅ HTML content generated ({len(html_content)} characters)")
        
        # Test text generation
        print("Testing text email generation...")
        text_content = email_service.generate_weekly_summary_text(mock_user, mock_summaries)
        print(f"✅ Text content generated ({len(text_content)} characters)")
        
        # Save sample email to file for review
        with open('/tmp/sample_email.html', 'w') as f:
            f.write(html_content)
        print("✅ Sample email saved to /tmp/sample_email.html")
        
        with open('/tmp/sample_email.txt', 'w') as f:
            f.write(text_content)
        print("✅ Sample email saved to /tmp/sample_email.txt")
        
        # Test with no summaries
        print("Testing email generation with no summaries...")
        empty_html = email_service.generate_weekly_summary_html(mock_user, [])
        empty_text = email_service.generate_weekly_summary_text(mock_user, [])
        print("✅ Empty summary email generation works")
        
        print("\n=== Email Service Test Results ===")
        print("✅ HTML email generation: PASSED")
        print("✅ Text email generation: PASSED")
        print("✅ Empty summary handling: PASSED")
        print("✅ Sample files created for review")
        
        print("\nNote: Actual email sending requires SMTP configuration.")
        print("Set environment variables: SMTP_SERVER, SMTP_PORT, EMAIL_ADDRESS, EMAIL_PASSWORD")
        
        return True
        
    except Exception as e:
        print(f"❌ Email service test failed: {e}")
        return False

if __name__ == "__main__":
    success = test_email_service()
    if success:
        print("\n✅ Email Service test completed successfully!")
    else:
        print("\n❌ Email Service test failed!")
        sys.exit(1)

